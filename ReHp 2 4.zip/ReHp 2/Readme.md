`Welcome To Blacklist`


`Secret : `\
`token`\
`MONGO_URL`

**you Dont have MongoDB url ?**\
Watch this video : [Creating a Cluster in MongoDB](https://www.youtube.com/watch?v=3ic5o6YuitE)

Need Support ? [Join Us](https://discord.gg/thailandcodess)
