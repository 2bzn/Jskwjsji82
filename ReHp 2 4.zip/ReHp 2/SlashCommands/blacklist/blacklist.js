const { MessageEmbed } = require("discord.js");
const blacklistModel = require("../../models/blacklist");

module.exports = {
  name: "blacklist",
  category: "blacklist",
  description: "Show the blacklisted users in this Server",
  run: async (client, interaction, args) => {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
    if (await blacklistModel.exists({ userId: interaction.user.id })) {
      return interaction.editReply({
        content: `:x: Error  | You have been BlackListed From the bot`
      });
    }
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
    const owner = ["965723397017444412"]
 if(!owner.includes(interaction.user.id)) { 
          return interaction.editReply(`You are not Owner to Use the Command`)}
    const currentPage = parseInt(interaction.options.get("page")?.value) || 1;

    const blacklistedusers = await blacklistModel.find({
      guildId: interaction.guild.id,
    });

    if (blacklistedusers.length === 0) {
      return interaction.editReply(`There are no blacklisted users available in this Server`);
    }

    const startIndex = (currentPage - 1) * 10;
    const endIndex = startIndex + 10;
    const slicedData = blacklistedusers.slice(startIndex, endIndex);

    const embed = new MessageEmbed()
      .setTitle(`${interaction.guild.name} Protection`)
      .setColor(`#8300FF`)
      .setTimestamp()
      .setFooter(
        `Blacklisted Users (Page ${currentPage} / ${Math.ceil(
          blacklistedusers.length / 10
        )})`
      );

    let description = "";

    for (const [index, data] of slicedData.entries()) {
      const userId = data.userId;

      let userTag;

      try {
        const user = await interaction.client.users.fetch(userId);
        userTag = `${user.tag} (${userId})`;
      } catch (error) {
        userTag = `<@!${userId}> (${userId})`;
      }

      const userNumber = startIndex + index + 1;
      description += `**${userNumber} -** \`${userTag}\`\n`;
    }

    embed.setDescription(description);

    interaction.editReply({ embeds: [embed] });
  },
};
