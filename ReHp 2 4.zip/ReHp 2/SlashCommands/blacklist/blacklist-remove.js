const { MessageEmbed } = require("discord.js");
const blacklistModel = require("../../models/blacklist");
const mongoose = require("mongoose");
module.exports = {
  name: "blacklistremove",
  description: "unblock user from use commands",
  options: [
    {
      name: "user",
      description: "user to be unblocked from use commands",
      type: 6,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
        if (await blacklistModel.exists({ userId: interaction.user.id })) {
      return interaction.editReply({
        content: `:x: Error  | You have been BlackListed From the bot`
      });
    }
    await interaction.deferReply({ ephemeral: true }).catch(() => {});
    const owner = ["965723397017444412"]
 if(!owner.includes(interaction.user.id)) { 
          return interaction.editReply(`You are not Owner to Use the Command`)}
    const user = interaction.options.getMember("user");
    const blacklisted = await blacklistModel.findOne({
      userId: user.id,
      guildId: interaction.guild.id,
    });

    if (!blacklisted) {
      return interaction.editReply({
        content: `This user is not blacklisted`,
        allowedMentions: { repliedUser: false },
      });
    }

    await blacklistModel.findOneAndDelete({
      userId: user.id,
      guildId: interaction.guild.id,
    });

    const embed = new MessageEmbed()
      .setTitle(`User Removed from blacklist`)
      .setDescription(`${user} has been Removed from the blacklist :white_check_mark:`)
      .setColor(`#8300FF`);

    interaction.editReply({ embeds: [embed] });
  },
};
