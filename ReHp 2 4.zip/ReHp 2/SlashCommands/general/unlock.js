const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "unlock",
  description: `"Allows @everyone or someone to send messages in channels."`,
  type: 'CHAT_INPUT',
  options:[
    {
      name: "all",
      type: 1,
      description: "Disables @everyone or someone to send messages in all channels. ",
      options: [
        {
          name:"user",
          description: "User to unlock channels on him.",
          type:6,
          required:false,
        }
      ],
    },
    {
      name: "channel",
      type: 1,
      description: "Disables @everyone or someone from sending messages in specific channel.",
      options: [
        {
          name:"target",
          description: "Channel to unlock.",
          type:7,
          required:false,
          channel_types:[0,5]
        },
        {
          name:"user",
          description: "User to unlock specific channel on him.",
          type:6,
          required:false,
        }
      ],
    },
  ],
  userPermissions: ["MANAGE_CHANNELS"],
  botPermissions:["MANAGE_CHANNELS","MANAGE_ROLES","EMBED_LINKS"],
  run: async (client, interaction, args) => {
        const embed = new MessageEmbed()
    .setColor(`#8300ff`)
          if(!interaction.member.permissions.has("MANAGE_CHANNELS")) return interaction.reply({ephemeral:true,embeds:[embed.setDescription(`**:x: You must have \`MANAGE_CHANNELS\` permission to do this command.**`)]})

    let subCommand = interaction.options._subcommand;
    let channel = interaction.options.getChannel("target") || interaction.channel;
    let user = interaction.options.getMember("user");
    if(subCommand === "all"){
      interaction.guild.channels.cache
      .filter(c => c.type !== "GUILD_VOICE" || c.type !== "GUILD_CATEGORY" || c.type !== "GUILD_STAGE_VOICE")
      .forEach(c => {
        c.permissionOverwrites.edit(user ? user.id : interaction.guild.id, {
          SEND_MESSAGES: true, 
        }).catch(err => 0)
      });
      let msgLock = `**🔒 All channels have been unlocked${user ? ` for ${user}` : ""}.**`;
      return interaction.reply({content:msgLock});
    }else if(subCommand === "channel"){
      channel.permissionOverwrites.edit(user ? user.id : interaction.guild.id, {
       SEND_MESSAGES: true
      });
      let msgUnLock = `**🔓 ${channel} has been unlocked${user ? ` for ${user}` : ""}.**`;
      return interaction.reply({content:msgUnLock});
      }

      
    },
};