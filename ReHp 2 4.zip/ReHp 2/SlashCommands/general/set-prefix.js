//const db = require('pro.db');
//const { Permissions } = require("discord.js");

//module.exports = {
  //name: 'set-prefix',
  //description: "test",
// To set bot prefix in bot
  //options: [{
   // name: "prefix",
    //description: "set the prefix the bot",
    //type: 3,
   // required: true
 // }],
  //execute(client, interaction, args, prefix) {
    //const prefix1 = interaction.options.getString("prefix");
    
   // if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) return interaction.reply("This command for ADMINISTRATOR Permissions")
   // new_prefix = prefix1
  //  if (!new_prefix) return interaction.reply("Add prefix please")
   // if (new_prefix.length > 5) return interaction.reply("Invild prefix, The prefix you provided is greater that 5 digits/alphabates")
   // interaction.reply(`The prefix has been set to **${new_prefix}**`)
   // db.set(`prefix_${interaction.guild.id}`, new_prefix)
 // }
//}