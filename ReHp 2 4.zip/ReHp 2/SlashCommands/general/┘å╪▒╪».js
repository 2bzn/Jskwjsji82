const { Client, CommandInteraction } = require("discord.js");

module.exports = {
    name: "نرد",
    description: "play",
    type: 'CHAT_INPUT',
    run: async (client, interaction, args, Discord) => {
    const N1 = ["3", "5", "1", "10", "7", "9", "8", "6", "2", "4", "11","15","13","17","14","19","12","16","18","20","24","21","23","25","22","27","29","26","28","30","33","31","34","32","35","37","39","36","38","40","45","43","47","42","49","41","44","46","50","48"];
    const R1 = Math.floor(Math.random() * N1.length);


                interaction.reply(` ${N1[R1]}`); 
        
    },
};