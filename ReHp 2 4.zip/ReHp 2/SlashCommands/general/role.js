const { MessageEmbed } = require("discord.js");
module.exports = {
  name: "role",
  description: "Add\/remove a role(s) for a user.",
  type: 'CHAT_INPUT',
  userPermissions: ["MANAGE_ROLES"],
  botPermissions:["MANAGE_ROLES"],
  options:[
    {
      type: 1,
      name:"give",
      description:"Gives a role to a user.",
      options:[
        {
          name:"user",
          description: "User to give role for.",
          type:6,
          required:true,
        },{
          name:"role",
          description: "The role to give.",
          type:8,
          required:true,
        }
      ]
    },
    {
      type:1,
      name:"remove",
      description:"Removes a role to a user.",
      options:[
        {
          name:"user",
          description: "User to remove role for.",
          type:6,
          required:true,
        },{
          name:"role",
          description: "The role to remove.",
          type:8,
          required:true,
        }
      ]
    },
    {
      type:1,
      name:"multiple",
      description:"Give / remove multiple users from a role.",
      options:[
        {
          name:"pick_type",
          description: "Pick a type",
          type:3,
          choices:[
            {
              name:"All",
              value:"all"
            },{
              name:"Bots",
              value:"bots"
            },{
              name:"Humans",
              value:"humans"
            }
          ],
          required:true,
        },
        {
          name:"give_or_remove",
          description: "Pick a type",
          type:3,
          choices:[
            {
              name:"Give",
              value:"give"
            },{
              name:"Remove",
              value:"remove"
            }
          ],
          required:true,
        },
        {
          name:"role",
          description: "The role to give / remove.",
          type:8,
          required:true,
        }
      ]
    }  
  ],
  run: async (client,interaction,args) => {
                    if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
    let typesubcommand = interaction.options._subcommand;
    let target = interaction.options.getMember("user");
    let role = interaction.options.getRole("role");
    if(role?.managed)return  interaction.reply(`🙄 - **${role}** is managed by integration and can't be given.`);
    if(interaction.guild.me.roles.highest.position <= role?.position) return interaction.reply({content:`🙄 - I couldn't change the roles for that user. Please check my permissions and role position.`, ephemeral: true});
    if (interaction.member.roles.highest.position <= role?.position && interaction.guild.ownerId !== interaction.member.id) return interaction.reply(`🙄 - **${role}**'s position higher than yours.`);
    if(typesubcommand === "give"){
                if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
      let embed = new MessageEmbed()
      .setDescription(`✅ Changed roles for ${target.user.username}, **+${role.name}**`)
      .setColor("#8300ff")
      target.roles.add(role.id).then(() =>{
        return interaction.reply({embeds:[embed]})
      }).catch(err => {
        return interaction.reply(`🙄 - I can't find the role **${role}**.`)
      })
    }
    else if(typesubcommand === "remove"){
      let embed = new MessageEmbed()
      .setDescription(`✅ Changed roles for ${target.user.username}, **-${role.name}**`)
      .setColor("#8300ff")
      target.roles.remove(role.id).then(() =>{
        return interaction.reply({embeds:[embed]})
      }).catch(err => {
        return interaction.reply(`🙄 - I can't find the role **${role}**.`)
       })
    }
    else if(typesubcommand === "multiple"){
                      if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
      let embed = new MessageEmbed()
      .setColor("#8300ff")
      if(!interaction.member.permissions.has("ADMINISTRATOR")) return interaction.reply({embeds:[embed.setDescription(`**🙄 - You must have Administrator permission to do this command.**`)]})
      
      let typepick = interaction.options.getString("pick_type")
      let typeaction = interaction.options.getString("give_or_remove");
      await interaction.guild.members.fetch().catch(err => 0)
      if(typepick === "all"){
                        if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
        if(typeaction === "give"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = interaction.guild.members.cache.filter(c => !c.roles.cache.has(role.id));
          embed.setDescription(`✅ Changing roles for ${members.size} members, +${role.name}`)
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.add(role.id).catch(err => 0)
          })
        }
        else if(typeaction === "remove"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = role.members.filter(c => c.roles.cache.has(role.id))
          embed.setDescription(`✅ Changing roles for ${members.size} members, -${role.name}`)
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.remove(role.id).catch(err=>0)
          })
        }
      }
      else if(typepick === "humans"){
                        if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
        if(typeaction === "give"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = interaction.guild.members.cache.filter(c => !c.user.bot && !c.roles.cache.has(role.id));
          embed.setDescription(`✅ Changing roles for ${members.size} members, +${role.name}`)
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.add(role.id).catch(err=>0)
          })
        }
        else if(typeaction === "remove"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = interaction.guild.members.cache.filter(c => !c.user.bot && c.roles.cache.has(role.id)); 
  embed.setDescription(`✅ Changing roles for ${members.size} members, -${role.name}`)
 
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.remove(role.id).catch(err=>0)
          })
        }
      }
      else if(typepick === "bots"){
                        if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
        if(typeaction === "give"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = interaction.guild.members.cache.filter(c => c.user.bot && !c.roles.cache.has(role.id));
          embed.setDescription(`✅ Changing roles for ${members.size} members, +${role.name}`)
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.add(role.id).catch(err=>0)
          })
        }
        else if(typeaction === "remove"){
                          if(!interaction.member.permissions.has('MANAGE_ROLES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_ROLES` لإستخدام هذا الأمر :x:", ephemeral: true});
          let members = interaction.guild.members.cache.filter(c => c.user.bot && c.roles.cache.has(role.id)); 
          embed.setDescription(`✅ Changing roles for ${members.size} members, -${role.name}`)
          interaction.reply({embeds:[embed]})
          members.forEach(async member => {
            await member.roles.remove(role.id).catch(err=>0)
          })
        }
      }
     }   
    },
};