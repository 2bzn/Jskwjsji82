const {MessageEmbed, Message, Client, CommandInteraction } = require("discord.js");

module.exports = {
        name: "ping",
        description: `To know the speed of the bot's response`,
        type: 'CHAT_INPUT',
  
        run: async (client, interaction, args) => {
          const embed = new MessageEmbed()
.setAuthor({ name: 'Reilnz Helper',
  iconURL: 'https://cdn.discordapp.com/attachments/1122563150357745846/1154091731017543841/2DFC49C1-C993-4B80-8A25-94EA2F6AF3FC.png',})
            .setColor(`#8300FF`)
                      .setDescription(`
  <:Latency:1152661931845492787> Latency is \`${Date.now() - interaction.createdTimestamp}ms\` 
   API Latency is \`${Math.round(client.ws.ping)}ms\`
   Ws Ping Is \`${client.ws.ping}\``)
.setTimestamp()
        interaction.reply({ embeds: [embed] });
    },
};