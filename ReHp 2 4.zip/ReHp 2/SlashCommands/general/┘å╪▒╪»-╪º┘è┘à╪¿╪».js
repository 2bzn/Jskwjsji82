const { Client, CommandInteraction, MessageEmbed } = require("discord.js");
module.exports = {
    name: "نرد-ايمبد",
    description: "play",
    type: 'CHAT_INPUT',
    run: async (client, interaction,args) => {
        if(!interaction.member.roles.cache.some((role) => role.id === '1150129003131326620')) return interaction.reply({content:`ليس لديك رتبة \`Game\` لتستخدم هذا الأمر :x:\n:x: You don't have a role \`Game\` to use this Command\n الرجاء طلب من أي اداري ليعطيك الرتبة - Please ask any staff to give a role`, ephemeral:true})
    const N2 = ["3", "5", "1", "10", "7", "9", "8", "6", "2", "4", "11","15","13","17","14","19","12","16","18","20","24","21","23","25","22","27","29","26","28","30","33","31","34","32","35","37","39","36","38","40","45","43","47","42","49","41","44","46","50","48"];
    const R2 = Math.floor(Math.random() * N2.length);
    const embed = new MessageEmbed()
      .setAuthor(`Reilnz Giveaway Support (Game)`)
      .setThumbnail(`https://cdn.discordapp.com/attachments/1122563150357745846/1154702438884974602/04FEF8DA-2BB2-43C8-B143-84BE4FC7F15C.png`)
    .setTitle(`> لعبة النرد`)
.setColor(`#8300FF`)
  // ${u.username}\n , <@${u.id}>\n
    .setDescription(`**لقد حصلت على \`${N2[R2]}\`** <:dices:1151481813420740678>`)
      .setTimestamp()
    .setFooter(`This game created by Reilnz Giveaway Support\n(For Fun)\nThe numbers appear to you Randomly\n The idea of the game : The number of attempts a person has 3 times, The first person to get three numbers higher than their opponent will lose opponent the game`)
                interaction.reply({embeds: [embed]}); 
        
    },
};