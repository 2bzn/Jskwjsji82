const { MessageEmbed } = require("discord.js")

module.exports = {
  name:`ban`,
  description: 'to ban someone.',
  type: 'CHAT_INPUT',
  options:[
    {
      name:"user",
      description: "User to ban.",
      type:6,
      required:true,
    },{
      name:"reason",
      description: "The reason of the ban.",
      type:3,
      required:false,
    }
  ],
  userPermissions:["BAN_MEMBERS"],
  botPermissions:["BAN_MEMBERS"],
  run:async(client, interaction,args) => {
        const embed = new MessageEmbed()
    .setColor(`#8300ff`)
          if(!interaction.member.permissions.has("BAN_MEMBERS")) return interaction.reply({ephemeral:true,embeds:[embed.setDescription(`**:x: You must have \`BAN_MEMBERS\` permission to do this command.**`)]})

    let target = interaction.options.getMember("user");
    if(!target) return;
    let reason = interaction.options.getString("reason") || "No Reason";
    if (
      target.roles.highest.position >=
      interaction.member.roles.highest.position
      && interaction.guild.ownerId !==  target.id
      &&  interaction.guild.ownerId !== interaction.member.id
      || interaction.guild.ownerId ==  target.id 
    ){
      return interaction.reply({ content: `🙄 - ** You can't ban @${target.user.username}. **`})
    }
    if(!target.bannable){
return interaction.reply({ content: `🙄 - I couldn't ban that user. Please check my permissions and role position.`})
    }
    target.ban({reason: reason}).then(c => {
      return interaction.reply({ content:`✅ **${target.user.username} banned from the server! ✈️** `})
    }).catch(err => 0);

  }
}