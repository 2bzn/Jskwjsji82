//const Discord = require("discord.js");
//const { MessageEmbed } = require('discord.js');
//const blacklistModel = require("../../models/blacklist");
//const client = new Discord.Client({ intents: 7753 });
//const random = require('random-password-pkg')
//const cooldowns = new Map();
//const db = require('best.db');

//module.exports = {
  //name: "thx",
 // description: "thx a Support",
 // options: [
  //  {
   //   name: "user",
    //  description: "User Support to thanks | حدد السبورت الذي تود أن تشكره",
  //    type : 6,
    //  required: true
  //  },
   // {
    //  name: "reason",
  //    description: "The reason for your thanks to the Support | اكتب سبب شكرك للسبورت",
    //  type: 3,
      required: true
  //  }
//  ],
 // run: async (client, interaction ) => {
  //  if (await blacklistModel.exists({ userId: interaction.user.id })) {
    //  return interaction.editReply({
    //    content: `:x: Error  | You have been BlackListed From the bot`, ephemeral: true
   //   });
 //   }
//  let r = interaction.options.getString("reason")
  //let u = interaction.options.getUser("user")
    //let role = db.get(`Support`) || []
//if (role && interaction.guild && u.id !== interaction.user.id) {
  //let member = interaction.guild.members.cache.get(u.id);
  //if (!member || !member.roles.cache.some((role) => role.id === '1113555066390057062')) return interaction.reply({content: `:x: The User isn't in Support Server Team\nPlease check the User have a role : **Support**\nAnd Try again later`});
  //if (!member || !member.roles.cache.has(role)) {
   // return interaction.reply({content: `**This is not staff**`});
    //if (interaction.member.roles.cache.has(role)) {
     // return interaction.reply({content: `**This is for members only**`, ephemeral: true});
  //  }
//if (interaction.user.id === u.id) {
    //  return interaction.reply("**You can't thank yourself**");
  //  }
    
//}
 // ;

  //  const now = Date.now();
   // const cdamount = 30 * 60 * 1000; 

  //  const userId = interaction.user.id;
   // if (cooldowns.has(userId)) {
   //   const expiret = cooldowns.get(userId) + cdamount;

     // if (now < expiret) {
     //   const tleft = (expiret - now) / 1000 / 60;
     //   return interaction.reply({content:`**Please wait ${tleft.toFixed(1)} more minutes before thanking someone again.**`});
   //   }
  //  }
  //  db.add(`points_${u.id}`, 1)
    //    const embed = new MessageEmbed()
    //  .setTitle(`<a:Thanks:1115361431106363474> New thx From a Member`)
    //  .setDescription(`**<:emoji_13:1115361429671915711> Thx For you'r Thank For ${u}**\n**Reason thx : ${r}**
  //    Successfuly added point to the Support +1`)
     //     .setTimestamp()
   //   .setFooter(`Made with by Reilnz Giveaway Support `)
   //   .setColor(`#8300FF`);
  //  cooldowns.set(userId, now);
 //   setTimeout(() => cooldowns.delete(userId), cdamount);
//    interaction.reply({ embeds: [embed] });
//  }
//};