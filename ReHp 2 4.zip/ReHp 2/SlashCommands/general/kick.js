const { MessageEmbed } = require("discord.js")

module.exports = {
  name:`kick`,
  description: 'to kick a someone.',
  type: 'CHAT_INPUT',
  options:[
      {
        name:"user",
        description: "The user to kick.",
        type:6,
        required:true,
      },{
        name:"reason",
        description: "Reason of the kick.",
        type:3,
        required:false,
      }
    ],
  userPermissions: ["KICK_MEMBERS"],
  botPermissions:["KICK_MEMBERS"],
  run:async(client, interaction,args) => {
        const embed = new MessageEmbed()
    .setColor(`#8300ff`)
          if(!interaction.member.permissions.has("KICK_MEMBERS")) return interaction.reply({ephemeral:true,embeds:[embed.setDescription(`**:x: You must have \`KICK_MEMBERS\` permission to do this command.**`)]})
    

const target = interaction.options.getMember("user");
    if(!target) return;
      const reason = interaction.options.getString("reason") || "No Reason";
      if (
      target.roles.highest.position >=
      interaction.member.roles.highest.position
      && interaction.guild.ownerId !==  target.id
      && interaction.guild.ownerId !== interaction.member.id
      || interaction.guild.ownerId ==  target.id
      
    ){
      return interaction.reply({ content: `🙄 - ** You can't kick @${target.user.username}. **`,ephemeral:true})
       }

       if (!target.kickable){
return interaction.reply({ content: `🙄 - I couldn't kick that user. Please check my permissions and role position.`,ephemeral:true})
         }
         target.kick({reason: reason}).then(c => {
           return interaction.reply({ content:`✅ **@${target.user.username} kicked from the server! **`})
         }).catch(err => 0)

  }
}