const { Client, CommandInteraction,MessageEmbed } = require("discord.js");
const cooldown = new Set();


module.exports = {
  name: "clear",
aliases: ["clear"],
  description: "Cleans messages from a channel",
  tybe : "CHAT_INPUT",
  userPermissions: ["MANAGE_MESSAGES"],
  botPermissions:["MANAGE_MESSAGES"],
  cooldown:20,
  options:[
    {
      name:"number_of_messages",
      description: "Number of messages to Delete.",
    type: 10,
      required:true,
    },//{
     // name:"message_by_user",
     // description: "Filter by user messages",
    //  type: 6,
     // required:false,
    //},{
    //  name:"message_by_role",
     // description: "Filter by role messages.",
     // type: 8,
     // required:false,
    //}
  ],
  run: async (client, interaction, args) => {
          if(!interaction.member.permissions.has('MANAGE_MESSAGES')) return interaction.reply({content: "ليس لديك صلاحية `MANAGE_MESSAGES` لإستخدام هذا الأمر :x:", ephemeral: true});
    let number = interaction.options.getNumber("number_of_messages");
    let role = interaction.options.getRole("filter_by_role");
    let member = interaction.options.getMember("filter_by_user");
         const u2 = interaction.user.id;
            if(cooldown.has(interaction.u2)) {
            interaction.reply('please wait for the cooldown to finish goddamit')
        } else {
    if (!number || number > 100 ||  number < 1) number = 100
    let message = await interaction.reply({
      content:`يتم حذف الرسائل ...`,
      fetchReply:true
     // ephemeral:true
    }).catch(err => 0)
    interaction.channel.messages.fetch({
     limit: 100,
    }).then(async(messages) => {
      if(member && !role){
        messages = messages.filter(m => m.id !== message.id && (m.author.id === member.id))
      }
      if(role && !member){
        messages = messages.filter(m => m.id !== message.id && (interaction.guild.members.cache.get(m.author.id)?.roles.cache.some(r => r.id === role.id)))
      }
      if(role && member){
        messages = messages.filter(m => m.id !== message.id && (interaction.guild.members.cache.get(m.author.id)?.roles.cache.some(r => r.id === role.id) || m.author.id === member.id))
      }
      if(!member && !role){
        messages = messages.filter(m => m.id !== message.id)
      }
      messages = messages.map(c => c).slice(0,number)
      await interaction.channel.bulkDelete(messages,true).then(async msgs => {
      // await interaction.deferReply().catch(Err => 0);
     return interaction.editReply({content: `\`\`\`js
تم مسح ${msgs.size} رسالة.
\`\`\``}).then(messages => setTimeout(() => interaction.deleteReply().catch(err=> 0), 3000))//.catch(err=> 0)
            
   }).catch(async(err) => {
     return interaction.editReply({content:`
    \`\`\`js\n0 تم حذف الرسالة.\`\`\``
    }).then(messages => setTimeout(() => interaction.deleteReply().catch(err=> 0), 3000)).catch(err=> 0)
        cooldown.add(interaction.user)
        setTimeout(() => {
            cooldown.delete(interaction.user)
        }, 5000);
    })
     })
      return;



  
    }
  }
};