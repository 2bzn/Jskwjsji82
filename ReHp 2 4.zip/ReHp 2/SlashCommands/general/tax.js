const { MessageEmbed , Discord } = require('discord.js');
const client = require('discord.js');
const blacklistModel = require("../../models/blacklist");
module.exports = {
  name:"tax",
  description:"to get probot tax of",
  options : [{
    name : "number",
    description : "number to get tax",
    type: 4,
    required : true,
  }],

  run: async(client, interaction, args) => {
    if (await blacklistModel.exists({ userId: interaction.user.id })) {
      return interaction.reply({
        content: `:x: Error  | You have been BlackListed From the bot`, ephemeral: true
      });
    }
    try {
      let args2 = interaction.options.getInteger('number')

      let tax = Math.floor(args2 * (20) / (19) + (1))
      let tax2 = Math.floor(args2 * (20) / (19) + (1)-(args2))
      let tax3 = Math.floor(tax2 * (20) / (19) + (1))
      let tax4 = Math.floor(tax2 + tax3 + args2)
      let errorembed3 = new MessageEmbed()
      .setTitle(`**Error**`)
      .setColor("#8300FF")
      .setDescription(`**It Must be a Number**`)
      .setFooter({text: interaction.guild.name, iconURL: interaction.guild.iconURL()})

      let errorembed2 = new MessageEmbed()
      .setTitle(`**Error**`)
      .setColor("8300FF")
      .setDescription(`**Must Be A Number**`)
      .setFooter({text: interaction.guild.name, iconURL: interaction.guild.iconURL()})
      if (isNaN(args2)) return interaction.reply({embeds:[errorembed2]});
      let errorembed = new MessageEmbed()
      .setTitle(`**Error**`)
      .setColor("8300FF")
      .setDescription(`**Must The Number Larger 1**`)
      .setFooter({text: interaction.guild.name, iconURL: interaction.guild.iconURL()})
      if (args2 < 1) return interaction.reply({embeds:[errorembed]});
      let tax_embed = new MessageEmbed()
      .setColor("8300FF")
.setThumbnail(`https://cdn.discordapp.com/attachments/1122563150357745846/1144951245098991626/D8130697-7F72-4814-9C29-0155408FF759.png`)
      .setAuthor({name: interaction.user.username, iconURL: interaction.user.avatarURL()})
      .setDescription(`
       ** __Your Tax Is : __${tax} **
      `)
      .setFooter({text: interaction.guild.name, iconURL: interaction.guild.iconURL()})

        let m = await interaction.reply({ embeds: [tax_embed] });

          if (i.customId === '2_embed') {
          m.edit({ embeds:[tax_embed] })
            
                  i.deferUpdate()
          } else {
            return;
          }; 
    } catch (err) {
      console.log(err)
  }
 }
}