const mongoose = require("mongoose");

const blacklistSchema = new mongoose.Schema({
  userId: String,
  guildId: String,
});

const blacklist = mongoose.model("blacklist", blacklistSchema);
module.exports = blacklist;
