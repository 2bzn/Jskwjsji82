const express = require('express')
const app = express();
const port = 3000

app.get('/', (req, res) => res.send('Bot is started'))

app.listen(port, () =>
console.log(`Creator: 7v._ #0`)
);
const prefix = '&';
const owner = ["965723397017444412","","","","",];
// Definitions
const { Client, Intents } = require('discord.js');
const { MessageAttachment } = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.DIRECT_MESSAGES, Intents.FLAGS.GUILD_MEMBERS], partials: ['MESSAGE', 'CHANNEL', 'REACTION']  });

client.on('ready', () => {
console.log(`Logged in as ${client.user.tag} Online`);
//client.user.setActivity(`best system`, {type:"PLAYING"})
//client.user.setStatus("online");
});

// ================================================================================
// PLAYING   1
// LISTENING 2
// WATCHING  3
// COMPETING 4
// ================================================================================
// online    1
// idle      2
// dnd       3
// offline   4
// ================================================================================


//npm i welcomer-gif لاتخرب فيه شي !!!
const Welcomer = require('welcomer-gif')


client.on("guildMemberAdd", async member => {
    // يعرف الداعي اذا دخل المدعو
    const inviter = await getInviter(member);
    

    // ايدي روم الترحيب
    const channel = await member.guild.channels.fetch("1135341508074143775");

    // ارسل رسالة الترحيب وتقدر تعدل عليها تحت
  await channel?.send({content:`<:emoji_6:1115361426329063474> - Welcome to ${member.guild.name} ${member}, We hope You Enjoy With us \n > <:Members:1123704781039485038> - We are Now ${member.guild.memberCount} Member \n > <:RulesServer:1135275711104548864> - Don't forget the <#1113559514030022758> \n > <:Fantastic:1123704514080428073> - Subscribe to our channel https://youtube.com/@ReilnzGiveawaySupport \n >  <:Invitedby:1135289786664488970> - Invited by ${inviter}`
    });
channel?.send({content:`https://cdn.discordapp.com/attachments/969712407083626586/1130986628198977556/4F3EFD94-EE6F-4F5F-9F37-06C43C6DAB8B.png`})
});


async function getInviter(member) {
    // تحصل على الداعي من المدعو بالسيرفر
    const invites = await member.guild.invites.fetch();
    const usedInvite = invites.find(invite => invite.uses > 0 && invite.inviter);

    // اذا الداعي مو معلوم 
    return usedInvite ? usedInvite.inviter.username : "Unknown";
}


// code &come Somebody
const { MessageButton, MessageActionRow } = require('discord.js')
const Discord = require('discord.js')
client.on("messageCreate", async th => {
if(th.content.startsWith(prefix + "come")){
if(!th.member.permissions.has('ADMINISTRATOR')) return th.reply("ليس لديك صلاحية `ADMINISTRATOR` لإستخدام هذا الأمر :x:");
  let id = th.content.split(' ')
      
let user = th.mentions.members.first() || th.guild.members.cache.get(id[1])
  if(!user)return th.reply(`Please Mention Member Or id `)
  if(user.user.bot)return th.reply(`**> You cant Send To the Bot**`)

  let invi = new MessageButton()
  .setLabel(`Come Here`)
  .setStyle(`LINK`)
.setURL(`https://discord.com/channels/${th.guild.id}/${th.channel.id}`) 
let inv = new MessageActionRow()
  .setComponents(invi)

  
  user.send({content: `<@${user.id}>`,embeds: [
    new Discord.MessageEmbed()
    
    .setDescription(`> ** Click Down Come Here to Go** 
  > ** the <@${th.author.id}> He needs You to Come**`)
    .setColor(`#8300FF`)
    .setTimestamp()
  ],components: [inv]}).then(async msg => {
      await th.reply({content: `**Done Send To ${user.user.tag}** :white_check_mark: `});
    }).catch(async (err) => await th.channel.send({content: `**I Cloudn't send A Come to this user **`}))
  setTimeout(() =>{
th.delete()
}, 1000);

  
  
}
})
// boost message
client.on('guildMemberUpdate', (oldMember, newMember) => {
  const { guild } = newMember;
  const channel = '1138572269615054879';
  if (!oldMember.premiumSince && newMember.premiumSince) {
    const ch = guild.channels.cache.get(channel);
    if (ch && ch.isText()) {
      ch.send(`${newMember.user} يعطيك العافيه على البوست <:emoji_6:1115361426329063474>`);
    }
  }
});
client.on("messageCreate", message => {
   const probot = require("probot-tax");
  if(message.content.startsWith( prefix + 'tax')) {
    let args = message.content.split(" ").slice(1).join(" ");
    if(!args) return message.reply({ content: '**من فضلك قم بكتابة المبلغ المطلوب حسابه **' })
if (args.endsWith("m")) args = args.replace(/m/gi, "") * 1000000;
else if (args.endsWith("k")) args = args.replace(/k/gi, "") * 1000;
else if (args.endsWith("K")) args = args.replace(/K/gi, "") * 1000;
else if (args.endsWith("M")) args = args.replace(/M/gi, "") * 1000000;
       let tax = Math.floor(probot.taxs() )
    let tax2 = Math.floor(args * (20) / (19) + (1) - (args))
    let tax3 = Math.floor(tax2 * (20) / (19) + (1))
    let tax4 = Math.floor(tax2 + tax3 ) 
  let tax5 = Math.floor(probot.taxs(args) + probot.taxs(args) - args )
      
    let tax6 = Math.floor(probot.taxs(args) - args)
    let embed = new Discord.MessageEmbed()
      .setColor('#8300ff')
      .setDescription("")
     .setAuthor({ name: 'Reilnz Giveaway Support tax', iconURL: 'https://cdn.discordapp.com/icons/1113549268075167776/375feaae598120c50ad98d3ea5d57a65.png?size=1024', })
      .setThumbnail(`https://cdn.discordapp.com/icons/1113549268075167776/375feaae598120c50ad98d3ea5d57a65.png?size=1024`)


    .addFields(
    
      {
      name:"`المبلغ مع الضرائب:`", value:`**${probot.taxs(args)}**`
 
    },
      {
        name:"`مبلغ الوسيط:`",
        value:`**${tax5}**`
        
      },
      {
      name:"` نسبة الوسيط: `",
        value:`**${tax2}**`
        
      }
 
    )
     .setFooter({ text: message.author.tag , iconURL: 
     message.author.displayAvatarURL({dynamic:true})})
    .setTimestamp()
 
        message.channel.send({ embeds: [embed] });
        }
});
// Installing the bot in an Voice Room
//const { joinVoiceChannel } = require('@discordjs/voice');
//client.on('ready', () => {
    
  //  setInterval( async () => {
    //client.channels.fetch("1116349824497877012") 
    // .then((channel) => { 
    //  const VoiceConnection = joinVoiceChannel({
     //  channelId: channel.id, 
     //  guildId: channel.guild.id, 
     //  adapterCreator: channel.guild.voiceAdapterCreator 
    //   });
  //  }).catch((error) => { return; });
  //  }, 1000)
//});
//const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */

// code cliam tickets 
//const mes = `
//** مرحبًا
// يرجى الإنتظار احد السبورت يرد عليك
//لو ما حد رد على التذكرة الخاصه بك خلال 10 دقائق من فتح التذكره يمكنك أن تمنشن اي سبورت مره واحدة فقط**`
//const line_ticket = "https://cdn.discordapp.com/attachments/969712407083626586/1130986628198977556/4F3EFD94-EE6F-4F5F-9F37-06C43C6DAB8B.png"
//client.on("channelCreate", async lucee => {
  //if (lucee.name.startsWith("ticket")) {
  //  setTimeout(() => {
    //  lucee.send({content: `${mes}`, files: ['https://cdn.discordapp.com/attachments/969712407083626586/1130986628198977556/4F3EFD94-EE6F-4F5F-9F37-06C43C6DAB8B.png']});
   // }, 3e3);
//  }
// });
const fs = require('fs');
let pointsData = {};

// تحميل بيانات النقاط من الملف
try {
  const pointsJSON = fs.readFileSync('points.json', 'utf8');
  pointsData = JSON.parse(pointsJSON);
} catch (error) {
  console.error("Error loading points data:", error);
}

client.on('messageCreate', async (message) => {
  
  if (message.author.bot) return;

  if (message.content.startsWith(prefix)) {
       if(!message.member.permissions.has('ADMINISTRATOR')) return message.reply("ليس لديك صلاحية `ADMINISTRATOR` لإستخدام هذا الأمر :x:");
    const args = message.content.slice(prefix.length).trim().split(" ");
  const command = args.shift().toLowerCase();
    if (command === "addpoint") {
      if (!message.mentions.users.size) {
        return message.reply('يجب عليك تحديد مستخدم لإضافة النقاط له!');
      }

      const user = message.mentions.users.first();
      const pointsToAdd = parseInt(args[1]);

      if (isNaN(pointsToAdd) || pointsToAdd <= 0) {
        return message.reply('يرجى تقديم قيمة صحيحة وإيجابية للنقاط.');
      }

      if (!pointsData[user.id]) {
        pointsData[user.id] = pointsToAdd;
      } else {
        pointsData[user.id] += pointsToAdd;
      }

      // حفظ بيانات النقاط في الملف
      fs.writeFileSync('points.json', JSON.stringify(pointsData, null, 2), 'utf8');

      return message.reply(`تمت إضافة ${pointsToAdd} نقطة للمستخدم <@${user.id}>.`);
    } //else if (command === "points") {
     // const user = message.mentions.users.first() || message.author;

     // const points = pointsData[user.id] || 0;
      //return message.channel.send(`.<@${user.id}> لديه ${points} نقطة`);

}
  }
);
const { MessageEmbed } = require('discord.js');
const db = require('pro.db')
client.on('messageCreate', async Rw => {
  let u = Rw.mentions.users.first() || Rw.author;
const points = pointsData[u.id] || 0;
if(Rw.content.startsWith(prefix + "points")){
  if(!Rw.member.roles.cache.some((role) => role.id === '1113555066390057062')) return Rw.reply(`:rolling_eyes: You'r Not in Support Server Team`);
const embed = new MessageEmbed()
  .setAuthor(Rw.author.username,Rw.author.displayAvatarURL({dynamic:true}))
  .setColor(`#8300FF`)
.setDescription(`**
الشخص  : <@${u.id}>

عدد نقاط الشخص هي : \`${points}\`
**`)

  
Rw.channel.send({embeds: [embed]});
}
});
//client.on("messageCreate", async message => {
  //let u = message.mentions.users.first() || message.author;
  //if (
  //  message.content == `نرد` || message.content == `dice`
  //) 
 // {
  //  if(!message.member.roles.cache.some((role) => role.id === '1150129003131326620')) return message.reply(`:x: You don't have a role \`Game\` to use the Command`)
  // if(!owner.includes(message.author.id)) return message.reply(`:x: You're not owner to use the Command`)
    //حط الأرقام الي تبيها
  //  var Numbers = ["3", "5", "1", "10", "7", "9", "8", "6", "2", "4", "11","15","13","17","14","19","12","16","18","20","24","21","23","25","22","27","29","26","28","0","30"];
   // var Random = Math.floor(Math.random() * Numbers.length);
//const embed = new MessageEmbed()
//.setAuthor({ name: 'Reilnz Giveaway Support Game',
  //iconURL: 'https://cdn.discordapp.com/attachments/1122563150357745846/1143943505576730755/D96003A9-7BC7-48DE-864D-0B58BAA95382.png',})

        //.setThumbnail(`https://cdn.discordapp.com/attachments/1122563150357745846/1151475393749065759/C3D5A272-C897-4A3E-9E46-9D2774BBAD32.png`)
   // .setTitle(`> Play Dice`)
//.setColor(`#8300FF`)
  // ${u.username}\n , <@${u.id}>\n
   // .setDescription(`**I got \`${Numbers[Random]}\` point(s)** <:dices:1151481813420740678>`)
            //  .setTimestamp()
    //.setFooter(`This game created by Reilnz Giveaway Support\n(For Fun)\nThe numbers appear to you Randomly\n The idea of the game : The number of attempts a person has 3 times, The first person to get three numbers higher than their opponent will lose `)
    
  //message.channel.send({content : `${message.author}`,embeds: [embed]});
   //  }
//});
var cooldown = new Set()
const ca = require("./config.json")
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const {message1,message2,Title,Des,r1,r1_name,r1_emoji,r2,r2_name,r2_emoji,r3,r3_name,r3_emoji,r4,r4_name,r4_emoji,r5,r5_name,r5_emoji} = require("./config.json")
client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
  });
  client.on("messageCreate", async (ReRlc) => {
    if (ReRlc.content == `sendRoles`)  
  {
      if(!owner.includes(ReRlc.author.id)) return ReRlc.reply(`:x: The Command For Owner Only`)
        const rw = new MessageActionRow().addComponents(
          new MessageButton()
            .setCustomId("r1")
            .setLabel(r1_name)
            .setEmoji(r1_emoji)
            .setStyle("SECONDARY"),
          new MessageButton()
            .setCustomId("r2")
            .setLabel(r2_name)
            .setEmoji(r2_emoji)
            .setStyle("SECONDARY"),
          new MessageButton()
            .setCustomId("r3")
            .setLabel(r3_name)
            .setEmoji(r3_emoji)
            .setStyle("SECONDARY"),
        );
        const roles = new MessageEmbed()
          .setColor(`#8300FF`)
          .setTitle(Title)
       .setFooter(`تحتاج إلى مساعدة في هذا الخادم أو في البوت ؟ توجه إلى support-ar#\nNeed help with this Server Or bot? Come to #support-en`)
          .setDescription('**Announcements**\nTo take the Role of Server News and bot News\n**Status**\nTo take the Role of Bot States of on, off and reset\n**Updates**\nTo take the Role of bot Command updates and New things in this Bot\n**Announcements**\nلأخذ رتبة منشن أخبار السيرفر وأخبار البوت\n**Status**\n لأخذ رتبة منشن حالات البوت من تشغيل وتوقيف وإعادة التعيين\n**Updates**\nلأخذ رتبة منشن تحديثات أوامر البوت والأشياء الجديدة لدى البوت ');
        ReRlc.channel.send({ embeds: [roles], components: [rw] });
    setTimeout(() =>{
ReRlc.delete()
}, 1000) 
    }
  });
// message1 = removed , message2 = added
  client.on("interactionCreate", async (interaction) => {
    if (interaction.isButton()) {
      if (interaction.customId == "r1") {
        if (interaction.member.roles.cache.some((role) => role.id == r1)) {
          interaction.reply({
            content: `${message1} **${r1_name}**`,
            ephemeral: true,
          });
          interaction.member.roles.remove(r1);
        } else {
          interaction.member.roles.add(r1);
          await interaction.reply({
            content: `${message2} **${r1_name}**`,
            ephemeral: true,
          });
        }
      } else if (interaction.customId == "r2") {
        if (interaction.member.roles.cache.some((role) => role.id == r2)) {
          interaction.reply({
            content: `${message1} **${r2_name}**`,
            ephemeral: true,
          });
          interaction.member.roles.remove(r2);
        } else {
          interaction.member.roles.add(r2);
          await interaction.reply({
            content: `${message2} **${r2_name}**`,
            ephemeral: true,
          });
        }
      } else if (interaction.customId == "r3") {
        if (interaction.member.roles.cache.some((role) => role.id == r3)) {
          interaction.reply({
            content: `${message1} **${r3_name}**`,
            ephemeral: true,
          });
          interaction.member.roles.remove(r3);
        } else {
          interaction.member.roles.add(r3);
          await interaction.reply({
            content: `${message2} **${r3_name}**`,
            ephemeral: true,
          });
        }
      } else if (interaction.customId == "r4") {
        if (interaction.member.roles.cache.some((role) => role.id == r4)) {
          interaction.reply({
            content: `${message1} <@&${r4}>`,
            ephemeral: true,
          });
          interaction.member.roles.remove(r4);
        } else {
          interaction.member.roles.add(r4);
          await interaction.reply({
            content: `${message2} <@&${r4}>`,
            ephemeral: true,
          });
        }
      } else if (interaction.customId == "r5") {
        if (interaction.member.roles.cache.some((role) => role.id == r5)) {
          interaction.reply({
            content: `${message1} <@&${r5}>`,
            ephemeral: true,
          });
          interaction.member.roles.remove(r5);
        } else {
          interaction.member.roles.add(r5);
          await interaction.reply({
            content: `${message2} <@&${r5}>`,
            ephemeral: true,
          });
        }
      }
    }
  });

//const prefix = !;
//client.on("messageCreate", message => {
//if(message.content === prefix +"help"){
   // let embed = new Discord.MessageEmbed()
   // .setThumbnail(message.guild.iconURL({dynamic:true}))
    // .setAuthor({name:message.author.tag,iconURL:message.author.avatarURL({dynamic:true})})
    //.setDescription(`> **Hello, I am a bot affiliated with the ${message.guild.name} server, and this is my list of commands**`)
    //.setColor(`#8300FF`)
//.setFooter("Reilnz Giveaway™ ")
      
   // .setTimestamp()
   // let row = new Discord.MessageActionRow()
   // .addComponents(
     //   new Discord.MessageButton()
      //  .setLabel("General Commands")
      //  .setStyle("PRIMARY")
     //   .setCustomId("1"),
      //  new Discord.MessageButton()
      //  .setLabel("Giveaway Prefix Commands")
      //  .setStyle("PRIMARY")
      //  .setCustomId("2")
  //  )

  
   // message.reply({embeds:[embed],components:[row],allowedMentions: { parse: [] }})
// }
// })
// client.on("interactionCreate", async interaction => {
// if(interaction.customId === "1"){
// let embed = new Discord.MessageEmbed()
// .setThumbnail(interaction.guild.iconURL({dynamic:true}))
// .setAuthor({name:interaction.user.tag,iconURL:interaction.user.avatarURL({dynamic:true})})
// .setDescription(`
// > **General Commands :** 
// \n${prefix}!ping\ - \`shows the Bot Response Time\` 
// \n${prefix}!help\ - \`Shows all available Commands to this bot\` 
// `)
  // \n${prefix}!gend\` - \`To end the giveaway\` 
// \n${prefix}!glist\` - \`List all the active giveaways for this Server\`
// \n${prefix}!embed\` - \`To Create a New Embed\` 
// \n${prefix}NameCommand\` - test 
// \n${prefix}NameCommand\` - test 
// \n${prefix}NameCommand\` - test 
// \n${prefix}NameCommand\` - test
// \n${prefix}tax\` - test
 //.setColor(`#8300FF`)
//.setFooter("Reilnz Giveaway™ ")
//.setTimestamp()
// interaction.reply({embeds:[embed], components: [],ephemeral:true});
// }else 
// if (interaction.customId === '2') {
// let embed = new Discord.MessageEmbed()
//.setThumbnail(interaction.guild.iconURL({dynamic:true}))
// .setAuthor({name:interaction.user.tag,iconURL:interaction.user.avatarURL({dynamic:true})})
//.setDescription(`
// > **Giveaway Prefix Commands :**
// \n${prefix}!gstart\` - \`To start the Giveaway\`
//\n${prefix}!gedit\` - \`To edit the giveaway\`
// \n${prefix}\`!gend - \`To end the giveaway\`
// \n${prefix}!glist\` - \`List all the active giveaways for this Server\` 
// \`${prefix}!embed\` - \`To Create a New Embed\` 
// `)
//.addField(`Link to add the bot:`,` 
 // [Invite Reilnz Giveaway](https://discord.com/api/oauth2/authorize?client_id=1118651249114484886&permissions=8&scope=bot%20applications.commands)\n **To Join a Support Server:**\n [Support Server](https://discord.gg/6pxZqtQt9g)\n**To Vote For a Bot:**\n [Vote Link](https://discordbotlist.com/bots/reilnz-giveaway/upvote#goog_rewarded)`,true)
// .setColor(`#8300FF`)
//.setFooter("Reilnz Giveaway™ ")
//.setTimestamp()
// interaction.reply({embeds:[embed], components: [],ephemeral:true});
// }
// })



  


var _0xf16c = ["events", "setMaxListeners", "discord.js", "mongoose", "config", "dotenv", "colors", "ready", "clear", "", "username", "user", "log", "Bot is now online!", "", "blue", "", "", "Reilnz Giveaway Support", "setActivity", "online", "setStatus", "strictQuery", "set", "env", "connect", "error", "MongoDB connection error:", "on", "open", "Connected to MongoDB", "once", "connection", "version", "exports", "commands", "slashCommands", "./handlers", "token", "login"];
const EventEmitter = require(_0xf16c[0]);
const emitter = new EventEmitter();
emitter[_0xf16c[1]](99999999999999999999);
const {
    Collection
} = require(_0xf16c[2]);
const mongoose = require(_0xf16c[3]);
require(_0xf16c[5])[_0xf16c[4]]();
const colors = require(_0xf16c[6]);
client[_0xf16c[28]](_0xf16c[7], async () => {
    console[_0xf16c[8]]();
    console[_0xf16c[12]](`${_0xf16c[9]}${client[_0xf16c[11]][_0xf16c[10]]}${_0xf16c[9]}`);
    console[_0xf16c[12]](_0xf16c[13]);
    console[_0xf16c[12]](colors[_0xf16c[15]](`${_0xf16c[14]}`));
    console[_0xf16c[12]](colors[_0xf16c[15]](`${_0xf16c[16]}`));
    console[_0xf16c[12]](colors[_0xf16c[15]](`${_0xf16c[17]}`));
    client[_0xf16c[11]][_0xf16c[19]](`${_0xf16c[18]}`);
    client[_0xf16c[11]][_0xf16c[21]](`${_0xf16c[20]}`);
    mongoose[_0xf16c[23]](_0xf16c[22], false);
    mongoose[_0xf16c[25]](process[_0xf16c[24]].MONGO_URL, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    });
    mongoose[_0xf16c[32]][_0xf16c[31]](_0xf16c[29], () => {
        console[_0xf16c[12]](_0xf16c[30])
    })[_0xf16c[28]](_0xf16c[26], (_0xe37ax6) => {
        console[_0xf16c[12]](_0xf16c[27], _0xe37ax6)
    })
});
console[_0xf16c[12]](process[_0xf16c[33]]);
module[_0xf16c[34]] = client;
client[_0xf16c[35]] = new Collection();
client[_0xf16c[36]] = new Collection();
require(_0xf16c[37])(client);
client[_0xf16c[39]](process[_0xf16c[24]][_0xf16c[38]])